import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Función para formatear moneda nicaragüense
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('es-NI', {
    style: 'currency',
    currency: 'NIO',
    currencyDisplay: 'code'
  }).format(amount).replace('NIO', 'C$')
}

// Función para formatear teléfonos nicaragüenses
export function formatPhone(phone: string): string {
  // Remover cualquier carácter que no sea número
  const cleaned = phone.replace(/\D/g, '')
  
  // Formatear según el patrón nicaragüense (8 dígitos)
  if (cleaned.length === 8) {
    return `${cleaned.slice(0, 4)}-${cleaned.slice(4)}`
  }
  
  return phone
}

// Función para validar email
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

// Función para generar colores de avatar
export function getAvatarColor(name: string): string {
  const colors = [
    'bg-red-500',
    'bg-blue-500',
    'bg-green-500',
    'bg-yellow-500',
    'bg-purple-500',
    'bg-pink-500',
    'bg-indigo-500',
    'bg-teal-500'
  ]
  
  const index = name.charCodeAt(0) % colors.length
  return colors[index]
}

// Función para obtener iniciales
export function getInitials(name: string): string {
  return name
    .split(' ')
    .map(part => part.charAt(0))
    .join('')
    .toUpperCase()
    .slice(0, 2)
}

// Función para formatear fechas
export function formatDate(date: string | Date): string {
  const d = new Date(date)
  return d.toLocaleDateString('es-NI', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  })
}

// Función para formatear fecha corta
export function formatShortDate(date: string | Date): string {
  const d = new Date(date)
  return d.toLocaleDateString('es-NI', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  })
}