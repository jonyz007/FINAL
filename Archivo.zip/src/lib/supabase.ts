import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Variables de entorno de Supabase no configuradas')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Tipos de datos para la aplicación
export interface Profile {
  id: string
  email: string
  full_name: string
  role: 'admin' | 'vendedor' | 'impresor'
  created_at: string
  updated_at: string
}

export interface Client {
  id: string
  full_name: string
  phone: string
  email?: string
  address?: string
  city?: string
  department?: string
  rating?: number
  notes?: string
  photo_url?: string
  created_by: string
  created_at: string
  updated_at: string
}

export interface Sale {
  id: string
  client_id: string
  seller_id: string
  product_name: string
  quantity: number
  unit_price: number
  total_amount: number
  currency: string
  status: 'pending' | 'processing' | 'completed' | 'cancelled'
  sale_date: string
  notes?: string
  created_at: string
  updated_at: string
}