import React, { useState } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { 
  User, 
  Mail, 
  Shield, 
  Calendar, 
  Edit,
  Save,
  Camera,
  Crown,
  Briefcase,
  Printer,
  Eye,
  EyeOff
} from 'lucide-react'
import { toast } from 'sonner'
import { getInitials, getAvatarColor, formatDate } from '@/lib/utils'

interface ProfileFormData {
  full_name: string
  email: string
}

interface PasswordFormData {
  currentPassword: string
  newPassword: string
  confirmPassword: string
}

export default function PerfilPage() {
  const { profile, user, refreshProfile } = useAuth()
  const [editing, setEditing] = useState(false)
  const [loading, setLoading] = useState(false)
  const [changingPassword, setChangingPassword] = useState(false)
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  })
  
  const [profileData, setProfileData] = useState<ProfileFormData>({
    full_name: profile?.full_name || '',
    email: profile?.email || ''
  })
  
  const [passwordData, setPasswordData] = useState<PasswordFormData>({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  })

  if (!profile || !user) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-2 text-sm text-gray-600">Cargando perfil...</p>
      </div>
    )
  }

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!profileData.full_name.trim()) {
      toast.error('El nombre es obligatorio')
      return
    }
    
    if (!profileData.email.trim()) {
      toast.error('El email es obligatorio')
      return
    }
    
    try {
      setLoading(true)
      
      // Actualizar perfil
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: profileData.full_name,
          email: profileData.email
        })
        .eq('id', profile.id)
      
      if (error) throw error
      
      // Actualizar email en auth si cambió
      if (profileData.email !== profile.email) {
        // Nota: En un entorno real, esto requería verificación por email
        toast.info('Para cambios de email, contacta al administrador')
      }
      
      toast.success('Perfil actualizado correctamente')
      setEditing(false)
      refreshProfile()
      
    } catch (error) {
      console.error('Error actualizando perfil:', error)
      toast.error('Error al actualizar el perfil')
    } finally {
      setLoading(false)
    }
  }
  
  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!passwordData.currentPassword) {
      toast.error('Ingresa tu contraseña actual')
      return
    }
    
    if (!passwordData.newPassword) {
      toast.error('Ingresa la nueva contraseña')
      return
    }
    
    if (passwordData.newPassword.length < 6) {
      toast.error('La nueva contraseña debe tener al menos 6 caracteres')
      return
    }
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error('Las contraseñas no coinciden')
      return
    }
    
    try {
      setLoading(true)
      
      // Actualizar contraseña en Supabase Auth
      const { error } = await supabase.auth.updateUser({
        password: passwordData.newPassword
      })
      
      if (error) throw error
      
      toast.success('Contraseña actualizada correctamente')
      setChangingPassword(false)
      setPasswordData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      })
      
    } catch (error) {
      console.error('Error actualizando contraseña:', error)
      toast.error('Error al actualizar la contraseña')
    } finally {
      setLoading(false)
    }
  }

  const getRoleInfo = (role: string) => {
    const roleMap = {
      admin: { label: 'Administrador', icon: Crown, color: 'text-yellow-600', bgColor: 'bg-yellow-100' },
      vendedor: { label: 'Vendedor', icon: Briefcase, color: 'text-blue-600', bgColor: 'bg-blue-100' },
      impresor: { label: 'Impresor', icon: Printer, color: 'text-gray-600', bgColor: 'bg-gray-100' }
    }
    return roleMap[role as keyof typeof roleMap] || roleMap.vendedor
  }
  
  const roleInfo = getRoleInfo(profile.role)
  const Icon = roleInfo.icon
  const initials = getInitials(profile.full_name)
  const avatarColor = getAvatarColor(profile.full_name)

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900">Mi Perfil</h1>
        <p className="text-gray-600">Gestiona tu información personal y configuración</p>
      </div>

      {/* Avatar y información básica */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            {/* Avatar */}
            <div className="relative">
              <div className={`w-24 h-24 rounded-full flex items-center justify-center text-white text-2xl font-bold ${avatarColor}`}>
                {initials}
              </div>
              <button className="absolute bottom-0 right-0 p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 shadow-lg">
                <Camera className="h-4 w-4" />
              </button>
            </div>
            
            {/* Información básica */}
            <div className="flex-1 text-center sm:text-left">
              <h2 className="text-2xl font-bold text-gray-900">{profile.full_name}</h2>
              <p className="text-gray-600 mb-2">{profile.email}</p>
              
              <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full ${roleInfo.bgColor}`}>
                <Icon className={`h-4 w-4 ${roleInfo.color}`} />
                <span className={`text-sm font-medium ${roleInfo.color}`}>{roleInfo.label}</span>
              </div>
            </div>
            
            {/* Estadísticas básicas */}
            <div className="grid grid-cols-2 gap-4 text-center">
              <div>
                <p className="text-sm text-gray-600">Miembro desde</p>
                <p className="font-semibold text-gray-900">
                  {formatDate(profile.created_at)}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Última actualización</p>
                <p className="font-semibold text-gray-900">
                  {formatDate(profile.updated_at)}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Información Personal */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Información Personal
            </CardTitle>
            <CardDescription>
              Actualiza tu información básica
            </CardDescription>
          </CardHeader>
          <CardContent>
            {editing ? (
              <form onSubmit={handleProfileSubmit} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Nombre Completo</label>
                  <Input
                    value={profileData.full_name}
                    onChange={(e) => setProfileData({ ...profileData, full_name: e.target.value })}
                    placeholder="Tu nombre completo"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email</label>
                  <Input
                    type="email"
                    value={profileData.email}
                    onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                    placeholder="tu@email.com"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Rol</label>
                  <div className="flex h-10 w-full rounded-md border border-input bg-gray-50 px-3 py-2 text-sm">
                    {roleInfo.label}
                  </div>
                  <p className="text-xs text-gray-500">El rol solo puede ser cambiado por un administrador</p>
                </div>
                
                <div className="flex gap-2">
                  <Button type="submit" disabled={loading}>
                    {loading ? (
                      <div className="flex items-center gap-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        Guardando...
                      </div>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Guardar
                      </>
                    )}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      setEditing(false)
                      setProfileData({
                        full_name: profile.full_name,
                        email: profile.email
                      })
                    }}
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            ) : (
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-600">Nombre Completo</label>
                  <p className="text-gray-900">{profile.full_name}</p>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-600">Email</label>
                  <p className="text-gray-900">{profile.email}</p>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-600">Rol</label>
                  <p className="text-gray-900">{roleInfo.label}</p>
                </div>
                
                <Button 
                  onClick={() => setEditing(true)}
                  variant="outline"
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Editar Información
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Cambiar Contraseña */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Seguridad
            </CardTitle>
            <CardDescription>
              Cambia tu contraseña para mantener tu cuenta segura
            </CardDescription>
          </CardHeader>
          <CardContent>
            {changingPassword ? (
              <form onSubmit={handlePasswordSubmit} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Contraseña Actual</label>
                  <div className="relative">
                    <Input
                      type={showPasswords.current ? 'text' : 'password'}
                      value={passwordData.currentPassword}
                      onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                      placeholder="Tu contraseña actual"
                      required
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 transform -translate-y-1/2"
                      onClick={() => setShowPasswords({ ...showPasswords, current: !showPasswords.current })}
                    >
                      {showPasswords.current ? <EyeOff className="h-4 w-4 text-gray-400" /> : <Eye className="h-4 w-4 text-gray-400" />}
                    </button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Nueva Contraseña</label>
                  <div className="relative">
                    <Input
                      type={showPasswords.new ? 'text' : 'password'}
                      value={passwordData.newPassword}
                      onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                      placeholder="Nueva contraseña (mínimo 6 caracteres)"
                      required
                      minLength={6}
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 transform -translate-y-1/2"
                      onClick={() => setShowPasswords({ ...showPasswords, new: !showPasswords.new })}
                    >
                      {showPasswords.new ? <EyeOff className="h-4 w-4 text-gray-400" /> : <Eye className="h-4 w-4 text-gray-400" />}
                    </button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Confirmar Nueva Contraseña</label>
                  <div className="relative">
                    <Input
                      type={showPasswords.confirm ? 'text' : 'password'}
                      value={passwordData.confirmPassword}
                      onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                      placeholder="Confirma tu nueva contraseña"
                      required
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 transform -translate-y-1/2"
                      onClick={() => setShowPasswords({ ...showPasswords, confirm: !showPasswords.confirm })}
                    >
                      {showPasswords.confirm ? <EyeOff className="h-4 w-4 text-gray-400" /> : <Eye className="h-4 w-4 text-gray-400" />}
                    </button>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button type="submit" disabled={loading}>
                    {loading ? (
                      <div className="flex items-center gap-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        Actualizando...
                      </div>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Actualizar Contraseña
                      </>
                    )}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      setChangingPassword(false)
                      setPasswordData({
                        currentPassword: '',
                        newPassword: '',
                        confirmPassword: ''
                      })
                    }}
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            ) : (
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-600">Contraseña</label>
                  <p className="text-gray-900">••••••••</p>
                  <p className="text-xs text-gray-500">Última actualización: {formatDate(profile.updated_at)}</p>
                </div>
                
                <Button 
                  onClick={() => setChangingPassword(true)}
                  variant="outline"
                >
                  <Shield className="h-4 w-4 mr-2" />
                  Cambiar Contraseña
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Información de sesión */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Información de Sesión
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <div>
              <p className="font-medium text-gray-600">ID de Usuario:</p>
              <p className="text-gray-900 font-mono text-xs">{user.id}</p>
            </div>
            <div>
              <p className="font-medium text-gray-600">Último Acceso:</p>
              <p className="text-gray-900">
                {user.last_sign_in_at 
                  ? new Date(user.last_sign_in_at).toLocaleString('es-NI')
                  : 'No disponible'
                }
              </p>
            </div>
            <div>
              <p className="font-medium text-gray-600">Email Confirmado:</p>
              <p className="text-gray-900">
                {user.email_confirmed_at ? (
                  <span className="text-green-600">Sí</span>
                ) : (
                  <span className="text-yellow-600">Pendiente</span>
                )}
              </p>
            </div>
            <div>
              <p className="font-medium text-gray-600">Fecha de Registro:</p>
              <p className="text-gray-900">
                {new Date(user.created_at).toLocaleDateString('es-NI')}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}