import React, { useState, useEffect } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { supabase, type Sale, type Client } from '@/lib/supabase'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { 
  FileText, 
  Download, 
  Calendar, 
  TrendingUp,
  Users,
  ShoppingCart,
  DollarSign,
  Filter,
  BarChart3,
  PieChart,
  FileBarChart
} from 'lucide-react'
import { toast } from 'sonner'
import { formatCurrency, formatShortDate } from '@/lib/utils'
import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'

interface ReportData {
  sales: Array<Sale & { client_name: string; seller_name: string }>
  clients: Client[]
  summary: {
    totalSales: number
    totalRevenue: number
    totalClients: number
    avgSaleValue: number
    salesByStatus: Record<string, number>
    salesByMonth: Record<string, number>
    topProducts: Array<{ product: string; count: number; revenue: number }>
  }
}

interface ReportFilters {
  startDate: string
  endDate: string
  seller_id: string
  status: string
  product_name: string
}

export default function ReportesPage() {
  const { profile } = useAuth()
  const [reportData, setReportData] = useState<ReportData | null>(null)
  const [sellers, setSellers] = useState<Array<{ id: string; full_name: string }>>([])
  const [loading, setLoading] = useState(false)
  const [generating, setGenerating] = useState(false)
  const [filters, setFilters] = useState<ReportFilters>({
    startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // Últimos 30 días
    endDate: new Date().toISOString().split('T')[0],
    seller_id: profile?.role === 'vendedor' ? profile.id : '',
    status: '',
    product_name: ''
  })

  useEffect(() => {
    loadSellers()
  }, [])

  const loadSellers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name')
        .in('role', ['admin', 'vendedor'])
        .order('full_name')
      
      if (error) throw error
      setSellers(data || [])
    } catch (error) {
      console.error('Error cargando vendedores:', error)
    }
  }

  const generateReport = async () => {
    if (!profile) return
    
    try {
      setLoading(true)
      
      // Construir consultas basadas en los filtros y permisos
      let salesQuery = supabase
        .from('sales')
        .select(`
          *,
          clients!inner(full_name),
          profiles!sales_seller_id_fkey(full_name)
        `)
        .gte('sale_date', filters.startDate)
        .lte('sale_date', filters.endDate)
        .order('sale_date', { ascending: false })
      
      let clientsQuery = supabase.from('clients').select('*')
      
      // Aplicar filtros de permisos
      if (profile.role === 'vendedor') {
        salesQuery = salesQuery.eq('seller_id', profile.id)
        clientsQuery = clientsQuery.eq('created_by', profile.id)
      }
      
      // Aplicar filtros adicionales
      if (filters.seller_id) {
        salesQuery = salesQuery.eq('seller_id', filters.seller_id)
      }
      
      if (filters.status) {
        salesQuery = salesQuery.eq('status', filters.status)
      }
      
      if (filters.product_name) {
        salesQuery = salesQuery.ilike('product_name', `%${filters.product_name}%`)
      }
      
      const [salesRes, clientsRes] = await Promise.all([
        salesQuery,
        clientsQuery
      ])
      
      if (salesRes.error) throw salesRes.error
      if (clientsRes.error) throw clientsRes.error
      
      const sales = (salesRes.data || []).map(sale => ({
        ...sale,
        client_name: sale.clients?.full_name || 'Cliente no encontrado',
        seller_name: sale.profiles?.full_name || 'Vendedor no encontrado'
      }))
      
      const clients = clientsRes.data || []
      
      // Calcular estadísticas
      const totalRevenue = sales.reduce((sum, sale) => sum + (sale.total_amount || 0), 0)
      const avgSaleValue = sales.length > 0 ? totalRevenue / sales.length : 0
      
      // Ventas por estado
      const salesByStatus = sales.reduce((acc, sale) => {
        acc[sale.status] = (acc[sale.status] || 0) + 1
        return acc
      }, {} as Record<string, number>)
      
      // Ventas por mes
      const salesByMonth = sales.reduce((acc, sale) => {
        const month = new Date(sale.sale_date).toLocaleDateString('es-NI', { year: 'numeric', month: 'long' })
        acc[month] = (acc[month] || 0) + 1
        return acc
      }, {} as Record<string, number>)
      
      // Productos más vendidos
      const productStats = sales.reduce((acc, sale) => {
        if (!acc[sale.product_name]) {
          acc[sale.product_name] = { count: 0, revenue: 0 }
        }
        acc[sale.product_name].count += sale.quantity
        acc[sale.product_name].revenue += sale.total_amount
        return acc
      }, {} as Record<string, { count: number; revenue: number }>)
      
      const topProducts = Object.entries(productStats)
        .map(([product, stats]) => ({ product, ...stats }))
        .sort((a, b) => b.revenue - a.revenue)
        .slice(0, 10)
      
      const summary = {
        totalSales: sales.length,
        totalRevenue,
        totalClients: clients.length,
        avgSaleValue,
        salesByStatus,
        salesByMonth,
        topProducts
      }
      
      setReportData({ sales, clients, summary })
      toast.success('Reporte generado correctamente')
      
    } catch (error) {
      console.error('Error generando reporte:', error)
      toast.error('Error al generar el reporte')
    } finally {
      setLoading(false)
    }
  }

  const generatePDF = async () => {
    if (!reportData) {
      toast.error('Primero genera un reporte')
      return
    }
    
    try {
      setGenerating(true)
      
      const pdf = new jsPDF('p', 'mm', 'a4')
      const pageWidth = pdf.internal.pageSize.width
      const pageHeight = pdf.internal.pageSize.height
      const margin = 20
      let yPosition = margin
      
      // Título
      pdf.setFontSize(20)
      pdf.setFont('helvetica', 'bold')
      pdf.text('CRM Nicaragua - Reporte de Ventas', margin, yPosition)
      yPosition += 10
      
      // Información del reporte
      pdf.setFontSize(10)
      pdf.setFont('helvetica', 'normal')
      pdf.text(`Generado el: ${new Date().toLocaleDateString('es-NI')}`, margin, yPosition)
      yPosition += 5
      pdf.text(`Periodo: ${filters.startDate} al ${filters.endDate}`, margin, yPosition)
      yPosition += 5
      pdf.text(`Generado por: ${profile?.full_name}`, margin, yPosition)
      yPosition += 15
      
      // Resumen ejecutivo
      pdf.setFontSize(14)
      pdf.setFont('helvetica', 'bold')
      pdf.text('Resumen Ejecutivo', margin, yPosition)
      yPosition += 10
      
      pdf.setFontSize(10)
      pdf.setFont('helvetica', 'normal')
      
      const summaryData = [
        ['Total de Ventas:', reportData.summary.totalSales.toString()],
        ['Ingresos Totales:', profile?.role !== 'impresor' ? formatCurrency(reportData.summary.totalRevenue) : 'N/A'],
        ['Total de Clientes:', reportData.summary.totalClients.toString()],
        ['Valor Promedio por Venta:', profile?.role !== 'impresor' ? formatCurrency(reportData.summary.avgSaleValue) : 'N/A']
      ]
      
      summaryData.forEach(([label, value]) => {
        pdf.text(`${label} ${value}`, margin, yPosition)
        yPosition += 6
      })
      
      yPosition += 10
      
      // Ventas por estado
      pdf.setFontSize(12)
      pdf.setFont('helvetica', 'bold')
      pdf.text('Ventas por Estado', margin, yPosition)
      yPosition += 8
      
      pdf.setFontSize(9)
      pdf.setFont('helvetica', 'normal')
      
      Object.entries(reportData.summary.salesByStatus).forEach(([status, count]) => {
        const statusLabels = {
          pending: 'Pendiente',
          processing: 'Procesando',
          completed: 'Completado',
          cancelled: 'Cancelado'
        }
        pdf.text(`${statusLabels[status as keyof typeof statusLabels] || status}: ${count}`, margin + 5, yPosition)
        yPosition += 5
      })
      
      yPosition += 10
      
      // Top productos
      if (reportData.summary.topProducts.length > 0) {
        pdf.setFontSize(12)
        pdf.setFont('helvetica', 'bold')
        pdf.text('Productos Más Vendidos', margin, yPosition)
        yPosition += 8
        
        pdf.setFontSize(8)
        pdf.setFont('helvetica', 'normal')
        
        reportData.summary.topProducts.slice(0, 5).forEach((product, index) => {
          const text = `${index + 1}. ${product.product} - Cantidad: ${product.count}${
            profile?.role !== 'impresor' ? ` - Ingresos: ${formatCurrency(product.revenue)}` : ''
          }`
          pdf.text(text, margin + 5, yPosition)
          yPosition += 5
        })
      }
      
      // Nueva página para el detalle de ventas
      pdf.addPage()
      yPosition = margin
      
      pdf.setFontSize(14)
      pdf.setFont('helvetica', 'bold')
      pdf.text('Detalle de Ventas', margin, yPosition)
      yPosition += 15
      
      // Tabla de ventas
      pdf.setFontSize(8)
      pdf.setFont('helvetica', 'bold')
      
      const headers = ['Fecha', 'Cliente', 'Producto', 'Cant.', 'Estado']
      if (profile?.role !== 'impresor') {
        headers.push('Total')
      }
      
      let xPosition = margin
      const colWidth = (pageWidth - 2 * margin) / headers.length
      
      headers.forEach((header, index) => {
        pdf.text(header, xPosition, yPosition)
        xPosition += colWidth
      })
      
      yPosition += 8
      pdf.setFont('helvetica', 'normal')
      
      reportData.sales.slice(0, 30).forEach((sale) => { // Máximo 30 ventas para evitar páginas muy largas
        if (yPosition > pageHeight - 20) {
          pdf.addPage()
          yPosition = margin
        }
        
        xPosition = margin
        const rowData = [
          formatShortDate(sale.sale_date),
          sale.client_name.substring(0, 15),
          sale.product_name.substring(0, 20),
          sale.quantity.toString(),
          sale.status
        ]
        
        if (profile?.role !== 'impresor') {
          rowData.push(formatCurrency(sale.total_amount).substring(0, 10))
        }
        
        rowData.forEach((data) => {
          pdf.text(data, xPosition, yPosition)
          xPosition += colWidth
        })
        
        yPosition += 5
      })
      
      if (reportData.sales.length > 30) {
        yPosition += 5
        pdf.setFontSize(8)
        pdf.setFont('helvetica', 'italic')
        pdf.text(`... y ${reportData.sales.length - 30} ventas más`, margin, yPosition)
      }
      
      // Footer
      const totalPages = pdf.internal.pages.length - 1
      for (let i = 1; i <= totalPages; i++) {
        pdf.setPage(i)
        pdf.setFontSize(8)
        pdf.setFont('helvetica', 'normal')
        pdf.text(`Página ${i} de ${totalPages}`, pageWidth - margin - 30, pageHeight - 10)
        pdf.text('CRM Nicaragua', margin, pageHeight - 10)
      }
      
      // Guardar PDF
      const fileName = `reporte-ventas-${filters.startDate}-${filters.endDate}.pdf`
      pdf.save(fileName)
      
      toast.success('PDF generado y descargado correctamente')
      
    } catch (error) {
      console.error('Error generando PDF:', error)
      toast.error('Error al generar el PDF')
    } finally {
      setGenerating(false)
    }
  }

  const exportCSV = () => {
    if (!reportData) {
      toast.error('Primero genera un reporte')
      return
    }
    
    try {
      const headers = ['Fecha', 'Cliente', 'Producto', 'Cantidad', 'Estado', 'Vendedor']
      if (profile?.role !== 'impresor') {
        headers.push('Precio Unitario', 'Total')
      }
      
      const csvContent = [
        headers.join(','),
        ...reportData.sales.map(sale => {
          const row = [
            sale.sale_date,
            `"${sale.client_name}"`,
            `"${sale.product_name}"`,
            sale.quantity,
            sale.status,
            `"${sale.seller_name}"`
          ]
          
          if (profile?.role !== 'impresor') {
            row.push(sale.unit_price.toString(), sale.total_amount.toString())
          }
          
          return row.join(',')
        })
      ].join('\n')
      
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
      const link = document.createElement('a')
      link.href = URL.createObjectURL(blob)
      link.download = `reporte-ventas-${filters.startDate}-${filters.endDate}.csv`
      link.click()
      
      toast.success('CSV exportado correctamente')
    } catch (error) {
      console.error('Error exportando CSV:', error)
      toast.error('Error al exportar CSV')
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Reportes</h1>
          <p className="text-gray-600">Genera reportes detallados de ventas y clientes</p>
        </div>
      </div>

      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros del Reporte
          </CardTitle>
          <CardDescription>
            Configura los parámetros para generar el reporte
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            <div className="space-y-2">
              <label className="text-sm font-medium">Fecha Inicio</label>
              <Input
                type="date"
                value={filters.startDate}
                onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Fecha Fin</label>
              <Input
                type="date"
                value={filters.endDate}
                onChange={(e) => setFilters({ ...filters, endDate: e.target.value })}
              />
            </div>
            
            {profile?.role === 'admin' && (
              <div className="space-y-2">
                <label className="text-sm font-medium">Vendedor</label>
                <select
                  value={filters.seller_id}
                  onChange={(e) => setFilters({ ...filters, seller_id: e.target.value })}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                >
                  <option value="">Todos los vendedores</option>
                  {sellers.map(seller => (
                    <option key={seller.id} value={seller.id}>{seller.full_name}</option>
                  ))}
                </select>
              </div>
            )}
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Estado</label>
              <select
                value={filters.status}
                onChange={(e) => setFilters({ ...filters, status: e.target.value })}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              >
                <option value="">Todos los estados</option>
                <option value="pending">Pendiente</option>
                <option value="processing">Procesando</option>
                <option value="completed">Completado</option>
                <option value="cancelled">Cancelado</option>
              </select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Producto</label>
              <Input
                value={filters.product_name}
                onChange={(e) => setFilters({ ...filters, product_name: e.target.value })}
                placeholder="Buscar producto..."
              />
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button 
              onClick={generateReport}
              disabled={loading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Generando...
                </div>
              ) : (
                <>
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Generar Reporte
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Resultados del reporte */}
      {reportData && (
        <>
          {/* Estadísticas generales */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <ShoppingCart className="h-8 w-8 text-blue-600" />
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Ventas</p>
                    <p className="text-2xl font-bold text-gray-900">{reportData.summary.totalSales}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {profile?.role !== 'impresor' && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <DollarSign className="h-8 w-8 text-green-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Ingresos Totales</p>
                      <p className="text-2xl font-bold text-gray-900">{formatCurrency(reportData.summary.totalRevenue)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <Users className="h-8 w-8 text-purple-600" />
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Clientes</p>
                    <p className="text-2xl font-bold text-gray-900">{reportData.summary.totalClients}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {profile?.role !== 'impresor' && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <TrendingUp className="h-8 w-8 text-orange-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Promedio por Venta</p>
                      <p className="text-2xl font-bold text-gray-900">{formatCurrency(reportData.summary.avgSaleValue)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Acciones de exportación */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="h-5 w-5" />
                Exportar Reporte
              </CardTitle>
              <CardDescription>
                Descarga el reporte en diferentes formatos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                <Button 
                  onClick={generatePDF}
                  disabled={generating}
                  variant="outline"
                  className="border-red-200 text-red-700 hover:bg-red-50"
                >
                  {generating ? (
                    <div className="flex items-center gap-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-600"></div>
                      Generando PDF...
                    </div>
                  ) : (
                    <>
                      <FileText className="h-4 w-4 mr-2" />
                      Descargar PDF
                    </>
                  )}
                </Button>
                
                <Button 
                  onClick={exportCSV}
                  variant="outline"
                  className="border-green-200 text-green-700 hover:bg-green-50"
                >
                  <FileBarChart className="h-4 w-4 mr-2" />
                  Exportar CSV
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Ventas por estado */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="h-5 w-5" />
                Distribución por Estado
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {Object.entries(reportData.summary.salesByStatus).map(([status, count]) => {
                  const statusInfo = {
                    pending: { label: 'Pendiente', color: 'bg-yellow-100 text-yellow-800' },
                    processing: { label: 'Procesando', color: 'bg-blue-100 text-blue-800' },
                    completed: { label: 'Completado', color: 'bg-green-100 text-green-800' },
                    cancelled: { label: 'Cancelado', color: 'bg-red-100 text-red-800' }
                  }[status] || { label: status, color: 'bg-gray-100 text-gray-800' }
                  
                  return (
                    <div key={status} className="text-center">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${statusInfo.color}`}>
                        {statusInfo.label}
                      </span>
                      <p className="text-2xl font-bold text-gray-900 mt-2">{count}</p>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Top productos */}
          {reportData.summary.topProducts.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Productos Más Vendidos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {reportData.summary.topProducts.slice(0, 5).map((product, index) => (
                    <div key={product.product} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-semibold">
                          {index + 1}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{product.product}</p>
                          <p className="text-sm text-gray-600">Cantidad vendida: {product.count}</p>
                        </div>
                      </div>
                      {profile?.role !== 'impresor' && (
                        <div className="text-right">
                          <p className="font-semibold text-gray-900">{formatCurrency(product.revenue)}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  )
}