import React, { useEffect, useState } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card'
import { supabase } from '@/lib/supabase'
import { formatCurrency } from '@/lib/utils'
import { 
  Users, 
  ShoppingCart, 
  TrendingUp, 
  DollarSign,
  Calendar,
  Star
} from 'lucide-react'

interface DashboardStats {
  totalClients: number
  totalSales: number
  totalRevenue: number
  avgRating: number
  recentSales: Array<{
    id: string
    client_name: string
    product_name: string
    total_amount: number
    sale_date: string
  }>
}

export default function Dashboard() {
  const { profile } = useAuth()
  const [stats, setStats] = useState<DashboardStats>(
    {
      totalClients: 0,
      totalSales: 0,
      totalRevenue: 0,
      avgRating: 0,
      recentSales: []
    }
  )
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadDashboardData()
  }, [profile])

  const loadDashboardData = async () => {
    if (!profile) return
    
    try {
      setLoading(true)
      
      // Consultas basadas en el rol
      let clientsQuery = supabase.from('clients').select('*')
      let salesQuery = supabase.from('sales').select('*, clients(full_name)')
      
      // Filtrar por vendedor si no es admin
      if (profile.role === 'vendedor') {
        clientsQuery = clientsQuery.eq('created_by', profile.id)
        salesQuery = salesQuery.eq('seller_id', profile.id)
      }
      
      const [clientsRes, salesRes] = await Promise.all([
        clientsQuery,
        salesQuery.order('created_at', { ascending: false }).limit(5)
      ])
      
      if (clientsRes.error) throw clientsRes.error
      if (salesRes.error) throw salesRes.error
      
      const clients = clientsRes.data || []
      const sales = salesRes.data || []
      
      // Calcular estadísticas
      const totalRevenue = sales.reduce((sum, sale) => sum + (sale.total_amount || 0), 0)
      const avgRating = clients.length > 0 
        ? clients.reduce((sum, client) => sum + (client.rating || 0), 0) / clients.length
        : 0
      
      setStats({
        totalClients: clients.length,
        totalSales: sales.length,
        totalRevenue,
        avgRating,
        recentSales: sales.map(sale => ({
          id: sale.id,
          client_name: sale.clients?.full_name || 'Cliente no encontrado',
          product_name: sale.product_name,
          total_amount: sale.total_amount,
          sale_date: sale.sale_date
        }))
      })
      
    } catch (error) {
      console.error('Error cargando datos del dashboard:', error)
    } finally {
      setLoading(false)
    }
  }
  
  const StatCard = ({ 
    title, 
    value, 
    icon, 
    description,
    color = 'blue'
  }: {
    title: string
    value: string | number
    icon: React.ReactNode
    description?: string
    color?: string
  }) => {
    const colorClasses = {
      blue: 'bg-blue-50 text-blue-600',
      green: 'bg-green-50 text-green-600',
      purple: 'bg-purple-50 text-purple-600',
      yellow: 'bg-yellow-50 text-yellow-600'
    }
    
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
          <div className={`h-8 w-8 rounded-md flex items-center justify-center ${colorClasses[color as keyof typeof colorClasses] || colorClasses.blue}`}>
            {icon}
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{value}</div>
          {description && (
            <p className="text-xs text-muted-foreground">{description}</p>
          )}
        </CardContent>
      </Card>
    )
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-sm text-gray-600">Cargando dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">
            Bienvenido, {profile?.full_name} 
            <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full capitalize">
              {profile?.role}
            </span>
          </p>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <Calendar className="h-4 w-4" />
          {new Date().toLocaleDateString('es-NI', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          })}
        </div>
      </div>

      {/* Estadísticas */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Clientes"
          value={stats.totalClients}
          icon={<Users className="h-4 w-4" />}
          description={profile?.role === 'vendedor' ? 'Mis clientes' : 'Todos los clientes'}
          color="blue"
        />
        
        <StatCard
          title="Total Ventas"
          value={stats.totalSales}
          icon={<ShoppingCart className="h-4 w-4" />}
          description={profile?.role === 'vendedor' ? 'Mis ventas' : 'Todas las ventas'}
          color="green"
        />
        
        {profile?.role !== 'impresor' && (
          <StatCard
            title="Ingresos Totales"
            value={formatCurrency(stats.totalRevenue)}
            icon={<DollarSign className="h-4 w-4" />}
            description="En córdobas nicaragüenses"
            color="purple"
          />
        )}
        
        <StatCard
          title="Calificación Promedio"
          value={stats.avgRating.toFixed(1)}
          icon={<Star className="h-4 w-4" />}
          description="De 1 a 5 estrellas"
          color="yellow"
        />
      </div>

      {/* Ventas recientes */}
      <Card>
        <CardHeader>
          <CardTitle>Ventas Recientes</CardTitle>
          <CardDescription>
            {profile?.role === 'vendedor' ? 'Tus últimas ventas' : 'Las últimas ventas registradas'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {stats.recentSales.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <ShoppingCart className="h-12 w-12 mx-auto mb-4 opacity-20" />
              <p>No hay ventas registradas</p>
            </div>
          ) : (
            <div className="space-y-4">
              {stats.recentSales.map((sale) => (
                <div
                  key={sale.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <ShoppingCart className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{sale.product_name}</p>
                      <p className="text-sm text-gray-600">{sale.client_name}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    {profile?.role !== 'impresor' && (
                      <p className="font-medium text-gray-900">
                        {formatCurrency(sale.total_amount)}
                      </p>
                    )}
                    <p className="text-xs text-gray-500">
                      {new Date(sale.sale_date).toLocaleDateString('es-NI')}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}