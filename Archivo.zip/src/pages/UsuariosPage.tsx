import React, { useState, useEffect } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { supabase, type Profile } from '@/lib/supabase'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { 
  Plus, 
  Search, 
  Users, 
  Edit,
  Trash2,
  Shield,
  UserCheck,
  UserX,
  Crown,
  Briefcase,
  Printer
} from 'lucide-react'
import { toast } from 'sonner'
import { getInitials, getAvatarColor } from '@/lib/utils'

interface UserFormData {
  email: string
  password: string
  full_name: string
  role: 'admin' | 'vendedor' | 'impresor'
}

interface UserWithStats extends Profile {
  clients_count?: number
  sales_count?: number
  total_revenue?: number
}

const initialFormData: UserFormData = {
  email: '',
  password: '',
  full_name: '',
  role: 'vendedor'
}

const roles = [
  { value: 'admin', label: 'Administrador', icon: Crown, color: 'text-yellow-600' },
  { value: 'vendedor', label: 'Vendedor', icon: Briefcase, color: 'text-blue-600' },
  { value: 'impresor', label: 'Impresor', icon: Printer, color: 'text-gray-600' }
]

export default function UsuariosPage() {
  const { profile } = useAuth()
  const [users, setUsers] = useState<UserWithStats[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingUser, setEditingUser] = useState<Profile | null>(null)
  const [formData, setFormData] = useState<UserFormData>(initialFormData)
  const [searchTerm, setSearchTerm] = useState('')
  const [roleFilter, setRoleFilter] = useState<string | null>(null)

  useEffect(() => {
    if (profile?.role === 'admin') {
      loadUsers()
    }
  }, [profile])

  const loadUsers = async () => {
    try {
      setLoading(true)
      
      // Cargar usuarios
      const { data: usersData, error: usersError } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false })
      
      if (usersError) throw usersError
      
      // Cargar estadísticas para cada usuario
      const usersWithStats = await Promise.all(
        (usersData || []).map(async (user) => {
          try {
            // Contar clientes
            const { count: clientsCount } = await supabase
              .from('clients')
              .select('*', { count: 'exact', head: true })
              .eq('created_by', user.id)
            
            // Contar ventas y calcular ingresos
            const { data: salesData } = await supabase
              .from('sales')
              .select('total_amount')
              .eq('seller_id', user.id)
              .eq('status', 'completed')
            
            const salesCount = salesData?.length || 0
            const totalRevenue = salesData?.reduce((sum, sale) => sum + (sale.total_amount || 0), 0) || 0
            
            return {
              ...user,
              clients_count: clientsCount || 0,
              sales_count: salesCount,
              total_revenue: totalRevenue
            }
          } catch (error) {
            console.error(`Error cargando stats para usuario ${user.id}:`, error)
            return {
              ...user,
              clients_count: 0,
              sales_count: 0,
              total_revenue: 0
            }
          }
        })
      )
      
      setUsers(usersWithStats)
    } catch (error) {
      console.error('Error cargando usuarios:', error)
      toast.error('Error al cargar los usuarios')
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validaciones
    if (!formData.email.trim()) {
      toast.error('El email es obligatorio')
      return
    }
    
    if (!formData.full_name.trim()) {
      toast.error('El nombre es obligatorio')
      return
    }
    
    if (!editingUser && !formData.password.trim()) {
      toast.error('La contraseña es obligatoria para usuarios nuevos')
      return
    }
    
    if (formData.password && formData.password.length < 6) {
      toast.error('La contraseña debe tener al menos 6 caracteres')
      return
    }
    
    try {
      if (editingUser) {
        // Actualizar usuario existente
        const { error } = await supabase
          .from('profiles')
          .update({
            email: formData.email,
            full_name: formData.full_name,
            role: formData.role
          })
          .eq('id', editingUser.id)
        
        if (error) throw error
        
        // Si se proporcionó nueva contraseña, actualizar en auth
        if (formData.password) {
          // Nota: En un entorno real, necesitarías una edge function para actualizar la contraseña
          toast.info('Perfil actualizado. La contraseña se actualizará en la próxima versión.')
        }
        
        toast.success('Usuario actualizado correctamente')
      } else {
        // Crear nuevo usuario
        // Nota: En un entorno real, necesitarías una edge function para crear usuarios
        // Por ahora, simularemos la creación del perfil
        
        // Generar un ID temporal para demostrar la funcionalidad
        const tempId = crypto.randomUUID()
        
        const { error } = await supabase
          .from('profiles')
          .insert({
            id: tempId,
            email: formData.email,
            full_name: formData.full_name,
            role: formData.role
          })
        
        if (error) {
          // Si el error es de clave foránea, significa que necesitamos crear el usuario en auth primero
          toast.error('Para crear usuarios reales, se necesita configurar una edge function')
          return
        }
        
        toast.success('Usuario creado correctamente')
      }
      
      // Resetear formulario y recargar datos
      setFormData(initialFormData)
      setEditingUser(null)
      setShowForm(false)
      loadUsers()
      
    } catch (error) {
      console.error('Error guardando usuario:', error)
      toast.error('Error al guardar el usuario')
    }
  }
  
  const handleEdit = (user: Profile) => {
    setEditingUser(user)
    setFormData({
      email: user.email,
      password: '', // No mostrar la contraseña actual
      full_name: user.full_name,
      role: user.role as 'admin' | 'vendedor' | 'impresor'
    })
    setShowForm(true)
  }
  
  const handleDelete = async (user: Profile) => {
    if (user.id === profile?.id) {
      toast.error('No puedes eliminar tu propia cuenta')
      return
    }
    
    if (!confirm(`¿Estás seguro de eliminar el usuario "${user.full_name}"?`)) {
      return
    }
    
    try {
      // Verificar si el usuario tiene clientes o ventas asociadas
      const [clientsRes, salesRes] = await Promise.all([
        supabase.from('clients').select('id').eq('created_by', user.id).limit(1),
        supabase.from('sales').select('id').eq('seller_id', user.id).limit(1)
      ])
      
      if (clientsRes.data && clientsRes.data.length > 0) {
        toast.error('No se puede eliminar: el usuario tiene clientes asociados')
        return
      }
      
      if (salesRes.data && salesRes.data.length > 0) {
        toast.error('No se puede eliminar: el usuario tiene ventas asociadas')
        return
      }
      
      const { error } = await supabase
        .from('profiles')
        .delete()
        .eq('id', user.id)
      
      if (error) throw error
      
      toast.success('Usuario eliminado correctamente')
      loadUsers()
    } catch (error) {
      console.error('Error eliminando usuario:', error)
      toast.error('Error al eliminar el usuario')
    }
  }
  
  const filteredUsers = users.filter(user => {
    const matchesSearch = user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesRole = roleFilter === null || user.role === roleFilter
    
    return matchesSearch && matchesRole
  })
  
  const getRoleInfo = (role: string) => {
    return roles.find(r => r.value === role) || roles[1]
  }
  
  // Solo admins pueden acceder
  if (profile?.role !== 'admin') {
    return (
      <div className="text-center py-12">
        <Shield className="h-12 w-12 mx-auto mb-4 text-red-500" />
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Acceso Denegado</h2>
        <p className="text-gray-600">Solo los administradores pueden gestionar usuarios.</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-2 text-sm text-gray-600">Cargando usuarios...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Usuarios</h1>
          <p className="text-gray-600">Gestiona los usuarios del sistema</p>
        </div>
        <Button 
          onClick={() => {
            setEditingUser(null)
            setFormData(initialFormData)
            setShowForm(true)
          }}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Nuevo Usuario
        </Button>
      </div>

      {/* Estadísticas */}
      <div className="grid gap-4 md:grid-cols-4">
        {roles.map(role => {
          const count = users.filter(u => u.role === role.value).length
          const Icon = role.icon
          
          return (
            <Card key={role.value}>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <Icon className={`h-8 w-8 ${role.color}`} />
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">{role.label}s</p>
                    <p className="text-2xl font-bold text-gray-900">{count}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-purple-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total</p>
                <p className="text-2xl font-bold text-gray-900">{users.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Formulario */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>
              {editingUser ? 'Editar Usuario' : 'Nuevo Usuario'}
            </CardTitle>
            <CardDescription>
              {editingUser 
                ? 'Modifica la información del usuario'
                : 'Crea una nueva cuenta de usuario'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email *</label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="usuario@ejemplo.com"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    Contraseña {editingUser ? '(dejar vacío si no se cambia)' : '*'}
                  </label>
                  <Input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    placeholder="Contraseña"
                    required={!editingUser}
                    minLength={6}
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Nombre Completo *</label>
                  <Input
                    value={formData.full_name}
                    onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                    placeholder="Juan Pérez"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Rol *</label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value as any })}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    required
                  >
                    {roles.map(role => (
                      <option key={role.value} value={role.value}>{role.label}</option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Permisos por Rol:</h4>
                <div className="space-y-1 text-sm text-blue-800">
                  <p><strong>Administrador:</strong> Control total, gestión de usuarios, todos los reportes</p>
                  <p><strong>Vendedor:</strong> Sus clientes y ventas, crear clientes, generar PDFs</p>
                  <p><strong>Impresor:</strong> Ver ventas, editar estado, sin precios</p>
                </div>
              </div>
              
              <div className="flex gap-2">
                <Button type="submit">
                  {editingUser ? 'Actualizar' : 'Crear'} Usuario
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowForm(false)
                    setEditingUser(null)
                    setFormData(initialFormData)
                  }}
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Filtros */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Buscar por nombre o email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={roleFilter || ''}
              onChange={(e) => setRoleFilter(e.target.value || null)}
              className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm"
            >
              <option value="">Todos los roles</option>
              {roles.map(role => (
                <option key={role.value} value={role.value}>{role.label}</option>
              ))}
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Lista de usuarios */}
      <div className="grid gap-4">
        {filteredUsers.length === 0 ? (
          <Card>
            <CardContent className="py-12">
              <div className="text-center text-gray-500">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-20" />
                <p>No hay usuarios registrados</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          filteredUsers.map((user) => {
            const roleInfo = getRoleInfo(user.role)
            const Icon = roleInfo.icon
            const initials = getInitials(user.full_name)
            const avatarColor = getAvatarColor(user.full_name)
            const isCurrentUser = user.id === profile?.id
            
            return (
              <Card key={user.id} className={`hover:shadow-md transition-shadow ${
                isCurrentUser ? 'ring-2 ring-blue-200 bg-blue-50' : ''
              }`}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className={`w-14 h-14 rounded-full flex items-center justify-center text-white font-semibold ${avatarColor}`}>
                      {initials}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                            {user.full_name}
                            {isCurrentUser && (
                              <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                                Tú
                              </span>
                            )}
                          </h3>
                          <p className="text-sm text-gray-600">{user.email}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Icon className={`h-4 w-4 ${roleInfo.color}`} />
                            <span className="text-sm font-medium capitalize">{roleInfo.label}</span>
                          </div>
                        </div>
                        
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(user)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          {!isCurrentUser && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDelete(user)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                      
                      {/* Estadísticas del usuario */}
                      {user.role === 'vendedor' && (
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm bg-gray-50 p-3 rounded-lg">
                          <div className="text-center">
                            <p className="font-medium text-gray-900">{user.clients_count || 0}</p>
                            <p className="text-gray-600">Clientes</p>
                          </div>
                          <div className="text-center">
                            <p className="font-medium text-gray-900">{user.sales_count || 0}</p>
                            <p className="text-gray-600">Ventas</p>
                          </div>
                          <div className="text-center">
                            <p className="font-medium text-gray-900">C$ {(user.total_revenue || 0).toLocaleString()}</p>
                            <p className="text-gray-600">Ingresos</p>
                          </div>
                        </div>
                      )}
                      
                      <div className="flex items-center justify-between mt-3 text-xs text-gray-500">
                        <span>Creado: {new Date(user.created_at).toLocaleDateString('es-NI')}</span>
                        <span>Actualizado: {new Date(user.updated_at).toLocaleDateString('es-NI')}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })
        )}
      </div>
    </div>
  )
}