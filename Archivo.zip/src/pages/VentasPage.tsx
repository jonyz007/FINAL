import React, { useState, useEffect } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { supabase, type Sale, type Client } from '@/lib/supabase'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Textarea } from '@/components/ui/Textarea'
import { 
  Plus, 
  Search, 
  Filter, 
  ShoppingCart, 
  Edit,
  Trash2,
  Eye,
  Calculator,
  Calendar,
  User,
  Package
} from 'lucide-react'
import { toast } from 'sonner'
import { formatCurrency, formatShortDate, getInitials, getAvatarColor } from '@/lib/utils'

interface SaleFormData {
  client_id: string
  product_name: string
  quantity: number
  unit_price: number
  sale_date: string
  notes: string
}

interface SaleWithClient extends Sale {
  client_name: string
  client_phone: string
}

const initialFormData: SaleFormData = {
  client_id: '',
  product_name: '',
  quantity: 1,
  unit_price: 0,
  sale_date: new Date().toISOString().split('T')[0],
  notes: ''
}

const saleStatuses = [
  { value: 'pending', label: 'Pendiente', color: 'bg-yellow-100 text-yellow-800' },
  { value: 'processing', label: 'Procesando', color: 'bg-blue-100 text-blue-800' },
  { value: 'completed', label: 'Completado', color: 'bg-green-100 text-green-800' },
  { value: 'cancelled', label: 'Cancelado', color: 'bg-red-100 text-red-800' }
]

export default function VentasPage() {
  const { profile } = useAuth()
  const [sales, setSales] = useState<SaleWithClient[]>([])
  const [clients, setClients] = useState<Client[]>([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [showForm, setShowForm] = useState(false)
  const [editingSale, setEditingSale] = useState<Sale | null>(null)
  const [formData, setFormData] = useState<SaleFormData>(initialFormData)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string | null>(null)
  const [dateFilter, setDateFilter] = useState('')
  const [dateRange, setDateRange] = useState<'today' | 'week' | 'month' | 'custom' | ''>('')

  useEffect(() => {
    loadData()
  }, [profile])

  // Calcular total automáticamente
  const totalAmount = formData.quantity * formData.unit_price

  const loadData = async () => {
    if (!profile) return
    
    try {
      setLoading(true)
      
      // Cargar clientes
      let clientsQuery = supabase.from('clients').select('*')
      if (profile.role === 'vendedor') {
        clientsQuery = clientsQuery.eq('created_by', profile.id)
      }
      
      // Cargar ventas
      let salesQuery = supabase.from('sales').select('*')
      if (profile.role === 'vendedor') {
        salesQuery = salesQuery.eq('seller_id', profile.id)
      }
      
      const [clientsRes, salesRes] = await Promise.all([
        clientsQuery.order('full_name'),
        salesQuery.order('created_at', { ascending: false })
      ])
      
      if (clientsRes.error) throw clientsRes.error
      if (salesRes.error) throw salesRes.error
      
      setClients(clientsRes.data || [])
      
      // Combinar datos de ventas con clientes
      const salesWithClients = (salesRes.data || []).map(sale => {
        const client = clientsRes.data?.find(c => c.id === sale.client_id)
        return {
          ...sale,
          client_name: client?.full_name || 'Cliente no encontrado',
          client_phone: client?.phone || ''
        }
      })
      
      setSales(salesWithClients)
    } catch (error) {
      console.error('Error cargando datos:', error)
      toast.error('Error al cargar los datos')
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!profile) return
    
    // Validaciones mejoradas
    if (!formData.client_id) {
      toast.error('Debe seleccionar un cliente')
      return
    }
    
    if (!formData.product_name.trim()) {
      toast.error('El nombre del producto es obligatorio')
      return
    }
    
    if (formData.product_name.length < 2) {
      toast.error('El nombre del producto debe tener al menos 2 caracteres')
      return
    }
    
    if (formData.quantity <= 0 || !Number.isInteger(formData.quantity)) {
      toast.error('La cantidad debe ser un número entero mayor a 0')
      return
    }
    
    if (formData.quantity > 10000) {
      toast.error('La cantidad no puede ser mayor a 10,000')
      return
    }
    
    if (formData.unit_price <= 0) {
      toast.error('El precio unitario debe ser mayor a 0')
      return
    }
    
    if (formData.unit_price > 100000) {
      toast.error('El precio unitario no puede ser mayor a C$ 100,000')
      return
    }
    
    if (totalAmount > 1000000) {
      toast.error('El total de la venta no puede exceder C$ 1,000,000')
      return
    }
    
    // Validar fecha
    const saleDate = new Date(formData.sale_date)
    const today = new Date()
    const maxFutureDate = new Date()
    maxFutureDate.setDate(today.getDate() + 30)
    
    if (saleDate > maxFutureDate) {
      toast.error('La fecha de venta no puede ser mayor a 30 días en el futuro')
      return
    }
    
    const minPastDate = new Date()
    minPastDate.setFullYear(today.getFullYear() - 2)
    
    if (saleDate < minPastDate) {
      toast.error('La fecha de venta no puede ser mayor a 2 años en el pasado')
      return
    }
    
    try {
      setSubmitting(true)
      const saleData = {
        ...formData,
        total_amount: totalAmount,
        currency: 'NIO',
        seller_id: profile.id
      }
      
      if (editingSale) {
        // Actualizar venta
        const { error } = await supabase
          .from('sales')
          .update(saleData)
          .eq('id', editingSale.id)
        
        if (error) throw error
        
        toast.success('Venta actualizada correctamente')
      } else {
        // Crear nueva venta
        const { error } = await supabase
          .from('sales')
          .insert(saleData)
        
        if (error) throw error
        
        toast.success('Venta creada correctamente')
      }
      
      // Resetear formulario y recargar datos
      setFormData(initialFormData)
      setEditingSale(null)
      setShowForm(false)
      loadData()
      
    } catch (error) {
      console.error('Error guardando venta:', error)
      toast.error('Error al guardar la venta')
    } finally {
      setSubmitting(false)
    }
  }
  
  const handleEdit = (sale: Sale) => {
    setEditingSale(sale)
    setFormData({
      client_id: sale.client_id,
      product_name: sale.product_name,
      quantity: sale.quantity,
      unit_price: sale.unit_price,
      sale_date: sale.sale_date,
      notes: sale.notes || ''
    })
    setShowForm(true)
  }
  
  const handleDelete = async (sale: Sale) => {
    const confirmMessage = `¿Estás seguro de eliminar esta venta?\n\nProducto: ${sale.product_name}\nCliente: ${sale.client_name}\nTotal: ${formatCurrency(sale.total_amount)}\n\nEsta acción no se puede deshacer.`
    
    if (!confirm(confirmMessage)) {
      return
    }
    
    try {
      const { error } = await supabase
        .from('sales')
        .delete()
        .eq('id', sale.id)
      
      if (error) throw error
      
      toast.success('Venta eliminada correctamente')
      loadData()
    } catch (error) {
      console.error('Error eliminando venta:', error)
      toast.error('Error al eliminar la venta')
    }
  }
  
  const handleStatusChange = async (sale: Sale, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('sales')
        .update({ status: newStatus })
        .eq('id', sale.id)
      
      if (error) throw error
      
      toast.success('Estado actualizado correctamente')
      loadData()
    } catch (error) {
      console.error('Error actualizando estado:', error)
      toast.error('Error al actualizar el estado')
    }
  }
  
  const filteredSales = sales.filter(sale => {
    const matchesSearch = 
      sale.product_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sale.client_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sale.client_phone.includes(searchTerm)
    
    const matchesStatus = statusFilter === null || sale.status === statusFilter
    
    // Filtro de fecha mejorado
    let matchesDate = true
    if (dateRange) {
      const saleDate = new Date(sale.sale_date)
      const today = new Date()
      today.setHours(0, 0, 0, 0)
      
      switch (dateRange) {
        case 'today':
          const todayStr = today.toISOString().split('T')[0]
          matchesDate = sale.sale_date === todayStr
          break
        case 'week':
          const weekAgo = new Date(today)
          weekAgo.setDate(today.getDate() - 7)
          matchesDate = saleDate >= weekAgo && saleDate <= today
          break
        case 'month':
          const monthAgo = new Date(today)
          monthAgo.setMonth(today.getMonth() - 1)
          matchesDate = saleDate >= monthAgo && saleDate <= today
          break
        case 'custom':
          matchesDate = !dateFilter || sale.sale_date === dateFilter
          break
      }
    }
    
    return matchesSearch && matchesStatus && matchesDate
  })
  
  const getStatusInfo = (status: string) => {
    return saleStatuses.find(s => s.value === status) || saleStatuses[0]
  }
  
  // Calcular estadísticas
  const stats = {
    total: filteredSales.length,
    completed: filteredSales.filter(s => s.status === 'completed').length,
    revenue: profile?.role !== 'impresor' ? filteredSales
      .filter(s => s.status === 'completed')
      .reduce((sum, s) => sum + s.total_amount, 0) : 0
  }

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-2 text-sm text-gray-600">Cargando ventas...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Ventas</h1>
          <p className="text-gray-600">
            {profile?.role === 'vendedor' ? 'Gestiona tus ventas' : 'Gestión de todas las ventas'}
          </p>
        </div>
        {profile?.role !== 'impresor' && (
          <Button 
            onClick={() => {
              setEditingSale(null)
              setFormData(initialFormData)
              setShowForm(true)
            }}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Nueva Venta
          </Button>
        )}
      </div>

      {/* Estadísticas */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <ShoppingCart className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Ventas</p>
                <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Package className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Completadas</p>
                <p className="text-2xl font-bold text-gray-900">{stats.completed}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {profile?.role !== 'impresor' && (
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Calculator className="h-8 w-8 text-purple-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Ingresos</p>
                  <p className="text-2xl font-bold text-gray-900">{formatCurrency(stats.revenue)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Formulario */}
      {showForm && profile?.role !== 'impresor' && (
        <Card>
          <CardHeader>
            <CardTitle>
              {editingSale ? 'Editar Venta' : 'Nueva Venta'}
            </CardTitle>
            <CardDescription>
              Completa la información de la venta
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Cliente *</label>
                  <select
                    value={formData.client_id}
                    onChange={(e) => setFormData({ ...formData, client_id: e.target.value })}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    required
                  >
                    <option value="">Seleccionar cliente</option>
                    {clients.map(client => (
                      <option key={client.id} value={client.id}>
                        {client.full_name} - {client.phone}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Producto/Servicio *</label>
                  <Input
                    value={formData.product_name}
                    onChange={(e) => setFormData({ ...formData, product_name: e.target.value })}
                    placeholder="Nombre del producto o servicio"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Cantidad *</label>
                  <Input
                    type="number"
                    min="1"
                    max="10000"
                    value={formData.quantity}
                    onChange={(e) => {
                      const value = parseInt(e.target.value) || 1
                      setFormData({ ...formData, quantity: Math.max(1, Math.min(10000, value)) })
                    }}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Precio Unitario (C$) *</label>
                  <Input
                    type="number"
                    min="0.01"
                    max="100000"
                    step="0.01"
                    value={formData.unit_price}
                    onChange={(e) => {
                      const value = parseFloat(e.target.value) || 0
                      setFormData({ ...formData, unit_price: Math.max(0, Math.min(100000, value)) })
                    }}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Fecha de Venta *</label>
                  <Input
                    type="date"
                    value={formData.sale_date}
                    onChange={(e) => setFormData({ ...formData, sale_date: e.target.value })}
                    min={(() => {
                      const minDate = new Date()
                      minDate.setFullYear(minDate.getFullYear() - 2)
                      return minDate.toISOString().split('T')[0]
                    })()}
                    max={(() => {
                      const maxDate = new Date()
                      maxDate.setDate(maxDate.getDate() + 30)
                      return maxDate.toISOString().split('T')[0]
                    })()}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Total</label>
                  <div className="flex h-10 w-full rounded-md border border-input bg-gray-50 px-3 py-2 text-sm font-semibold">
                    {formatCurrency(totalAmount)}
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Notas</label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Información adicional sobre la venta..."
                  rows={3}
                />
              </div>
              
              <div className="flex gap-2">
                <Button type="submit" disabled={submitting}>
                  {submitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      {editingSale ? 'Actualizando...' : 'Creando...'}
                    </>
                  ) : (
                    <>
                      {editingSale ? 'Actualizar' : 'Crear'} Venta
                    </>
                  )}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowForm(false)
                    setEditingSale(null)
                    setFormData(initialFormData)
                  }}
                  disabled={submitting}
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Filtros */}
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-4">
            {/* Barra de búsqueda */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Buscar por producto, cliente o teléfono..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            {/* Filtros en grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Filtro de estado */}
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-gray-500" />
                <select
                  value={statusFilter || ''}
                  onChange={(e) => setStatusFilter(e.target.value || null)}
                  className="flex-1 h-10 rounded-md border border-input bg-background px-3 py-2 text-sm"
                >
                  <option value="">Todos los estados</option>
                  {saleStatuses.map(status => (
                    <option key={status.value} value={status.value}>{status.label}</option>
                  ))}
                </select>
              </div>
              
              {/* Filtro de rango de fechas */}
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-gray-500" />
                <select
                  value={dateRange}
                  onChange={(e) => {
                    const value = e.target.value as typeof dateRange
                    setDateRange(value)
                    if (value !== 'custom') {
                      setDateFilter('')
                    }
                  }}
                  className="flex-1 h-10 rounded-md border border-input bg-background px-3 py-2 text-sm"
                >
                  <option value="">Todas las fechas</option>
                  <option value="today">Hoy</option>
                  <option value="week">Última semana</option>
                  <option value="month">Último mes</option>
                  <option value="custom">Fecha específica</option>
                </select>
              </div>
              
              {/* Fecha personalizada (solo se muestra cuando se selecciona 'custom') */}
              {dateRange === 'custom' && (
                <div>
                  <Input
                    type="date"
                    value={dateFilter}
                    onChange={(e) => setDateFilter(e.target.value)}
                    className="w-full"
                  />
                </div>
              )}
              
              {/* Botón limpiar filtros */}
              {(searchTerm || statusFilter || dateRange) && (
                <div>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSearchTerm('')
                      setStatusFilter(null)
                      setDateRange('')
                      setDateFilter('')
                    }}
                    className="w-full"
                  >
                    Limpiar filtros
                  </Button>
                </div>
              )}
            </div>
            
            {/* Resumen de filtros */}
            <div className="text-sm text-gray-600">
              Mostrando {filteredSales.length} de {sales.length} ventas
              {statusFilter && (
                <span className="ml-2">
                  • Estado: {saleStatuses.find(s => s.value === statusFilter)?.label}
                </span>
              )}
              {dateRange && (
                <span className="ml-2">
                  • {dateRange === 'today' ? 'Hoy' : 
                      dateRange === 'week' ? 'Última semana' : 
                      dateRange === 'month' ? 'Último mes' : 
                      dateRange === 'custom' && dateFilter ? `Fecha: ${formatShortDate(dateFilter)}` : 'Fecha personalizada'}
                </span>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de ventas */}
      <div className="grid gap-4">
        {filteredSales.length === 0 ? (
          <Card>
            <CardContent className="py-12">
              <div className="text-center text-gray-500">
                <ShoppingCart className="h-12 w-12 mx-auto mb-4 opacity-20" />
                <p>No hay ventas registradas</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          filteredSales.map((sale) => {
            const statusInfo = getStatusInfo(sale.status)
            
            return (
              <Card key={sale.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <Package className="h-6 w-6 text-blue-600" />
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900">
                              {sale.product_name}
                            </h3>
                            <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                              <div className="flex items-center gap-1">
                                <User className="h-4 w-4" />
                                <span>{sale.client_name}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                <span>{formatShortDate(sale.sale_date)}</span>
                              </div>
                            </div>
                          </div>
                          
                          <div className="text-right">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusInfo.color}`}>
                              {statusInfo.label}
                            </span>
                            {profile?.role !== 'impresor' && (
                              <p className="text-lg font-semibold text-gray-900 mt-1">
                                {formatCurrency(sale.total_amount)}
                              </p>
                            )}
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mt-4">
                          <div>
                            <span className="font-medium">Cantidad:</span>
                            <span className="ml-1">{sale.quantity}</span>
                          </div>
                          {profile?.role !== 'impresor' && (
                            <div>
                              <span className="font-medium">Precio Unit:</span>
                              <span className="ml-1">{formatCurrency(sale.unit_price)}</span>
                            </div>
                          )}
                          <div>
                            <span className="font-medium">Moneda:</span>
                            <span className="ml-1">{sale.currency}</span>
                          </div>
                          <div>
                            <span className="font-medium">Vendedor:</span>
                            <span className="ml-1">{sale.seller_id === profile?.id ? 'Yo' : 'Otro'}</span>
                          </div>
                        </div>
                        
                        {sale.notes && (
                          <p className="text-sm text-gray-600 mt-3">
                            <strong>Notas:</strong> {sale.notes}
                          </p>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex flex-col gap-2 ml-4">
                      {/* Cambiar estado */}
                      <select
                        value={sale.status}
                        onChange={(e) => handleStatusChange(sale, e.target.value)}
                        className="text-xs rounded border border-gray-300 px-2 py-1"
                        disabled={profile?.role === 'impresor' && sale.status === 'completed'}
                      >
                        {saleStatuses.map(status => (
                          <option key={status.value} value={status.value}>{status.label}</option>
                        ))}
                      </select>
                      
                      {/* Acciones */}
                      {profile?.role !== 'impresor' && (
                        <div className="flex gap-1">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(sale)}
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDelete(sale)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })
        )}
      </div>
    </div>
  )
}