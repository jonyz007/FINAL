import React, { useState, useEffect, useRef } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { supabase, type Client } from '@/lib/supabase'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Textarea } from '@/components/ui/Textarea'
import { useClientPhotoUpload } from '@/hooks/useClientPhotoUpload'
import { 
  Plus, 
  Search, 
  Filter, 
  Phone, 
  Mail, 
  MapPin, 
  Star, 
  Edit,
  Trash2,
  Users,
  Camera,
  Upload,
  X
} from 'lucide-react'
import { toast } from 'sonner'
import { formatPhone, getInitials, getAvatarColor } from '@/lib/utils'

interface ClientFormData {
  full_name: string
  phone: string
  email: string
  address: string
  city: string
  department: string
  rating: number
  notes: string
}

const initialFormData: ClientFormData = {
  full_name: '',
  phone: '',
  email: '',
  address: '',
  city: '',
  department: '',
  rating: 5,
  notes: ''
}

const departments = [
  'Boaco', 'Carazo', 'Chinandega', 'Chontales', 'Estelí',
  'Granada', 'Jinotega', 'León', 'Madriz', 'Managua',
  'Masaya', 'Matagalpa', 'Nueva Segovia', 'Río San Juan',
  'Rivas', 'RAAN', 'RAAS'
]

export default function ClientesPage() {
  const { profile } = useAuth()
  const { uploadPhoto, uploadPhotoFallback, uploading } = useClientPhotoUpload()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [clients, setClients] = useState<Client[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingClient, setEditingClient] = useState<Client | null>(null)
  const [formData, setFormData] = useState<ClientFormData>(initialFormData)
  const [searchTerm, setSearchTerm] = useState('')
  const [ratingFilter, setRatingFilter] = useState<number | null>(null)
  const [uploadingFor, setUploadingFor] = useState<string | null>(null)

  useEffect(() => {
    loadClients()
  }, [profile])

  const loadClients = async () => {
    if (!profile) return
    
    try {
      setLoading(true)
      
      let query = supabase.from('clients').select('*')
      
      // Filtrar por vendedor si no es admin
      if (profile.role === 'vendedor') {
        query = query.eq('created_by', profile.id)
      }
      
      const { data, error } = await query.order('created_at', { ascending: false })
      
      if (error) throw error
      
      setClients(data || [])
    } catch (error) {
      console.error('Error cargando clientes:', error)
      toast.error('Error al cargar los clientes')
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!profile) return
    
    // Validaciones
    if (!formData.full_name.trim()) {
      toast.error('El nombre es obligatorio')
      return
    }
    
    if (!formData.phone.trim()) {
      toast.error('El teléfono es obligatorio')
      return
    }
    
    if (formData.phone.replace(/\D/g, '').length !== 8) {
      toast.error('El teléfono debe tener 8 dígitos')
      return
    }
    
    try {
      const clientData = {
        ...formData,
        phone: formData.phone.replace(/\D/g, ''), // Solo números
        email: formData.email || null,
        address: formData.address || null,
        city: formData.city || null,
        department: formData.department || null,
        notes: formData.notes || null,
        created_by: profile.id
      }
      
      if (editingClient) {
        // Actualizar cliente
        const { error } = await supabase
          .from('clients')
          .update(clientData)
          .eq('id', editingClient.id)
        
        if (error) throw error
        
        toast.success('Cliente actualizado correctamente')
      } else {
        // Crear nuevo cliente
        const { error } = await supabase
          .from('clients')
          .insert(clientData)
        
        if (error) throw error
        
        toast.success('Cliente creado correctamente')
      }
      
      // Resetear formulario y recargar datos
      setFormData(initialFormData)
      setEditingClient(null)
      setShowForm(false)
      loadClients()
      
    } catch (error) {
      console.error('Error guardando cliente:', error)
      toast.error('Error al guardar el cliente')
    }
  }
  
  const handleEdit = (client: Client) => {
    setEditingClient(client)
    setFormData({
      full_name: client.full_name,
      phone: client.phone,
      email: client.email || '',
      address: client.address || '',
      city: client.city || '',
      department: client.department || '',
      rating: client.rating || 5,
      notes: client.notes || ''
    })
    setShowForm(true)
  }
  
  const handleDelete = async (client: Client) => {
    if (!confirm(`¿Estás seguro de eliminar el cliente "${client.full_name}"?`)) {
      return
    }
    
    try {
      const { error } = await supabase
        .from('clients')
        .delete()
        .eq('id', client.id)
      
      if (error) throw error
      
      toast.success('Cliente eliminado correctamente')
      loadClients()
    } catch (error) {
      console.error('Error eliminando cliente:', error)
      toast.error('Error al eliminar el cliente')
    }
  }
  
  const handlePhotoUpload = async (client: Client, file: File) => {
    setUploadingFor(client.id)
    
    try {
      // Intentar con edge function primero
      let photoUrl = await uploadPhoto({ file, clientId: client.id })
      
      // Si falla, usar método de fallback
      if (!photoUrl) {
        photoUrl = await uploadPhotoFallback({ file, clientId: client.id })
      }
      
      if (photoUrl) {
        // Recargar clientes para mostrar la nueva foto
        loadClients()
      }
    } catch (error) {
      console.error('Error subiendo foto:', error)
      toast.error('Error al subir la foto')
    } finally {
      setUploadingFor(null)
    }
  }
  
  const triggerPhotoUpload = (client: Client) => {
    if (fileInputRef.current) {
      fileInputRef.current.onchange = (e) => {
        const file = (e.target as HTMLInputElement).files?.[0]
        if (file) {
          handlePhotoUpload(client, file)
        }
        // Limpiar el input para permitir seleccionar el mismo archivo otra vez
        if (fileInputRef.current) {
          fileInputRef.current.value = ''
        }
      }
      fileInputRef.current.click()
    }
  }
  
  const filteredClients = clients.filter(client => {
    const matchesSearch = client.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.phone.includes(searchTerm) ||
      (client.email && client.email.toLowerCase().includes(searchTerm.toLowerCase()))
    
    const matchesRating = ratingFilter === null || client.rating === ratingFilter
    
    return matchesSearch && matchesRating
  })
  
  const StarRating = ({ rating, onChange, readOnly = false }: {
    rating: number
    onChange?: (rating: number) => void
    readOnly?: boolean
  }) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            disabled={readOnly}
            onClick={() => onChange && onChange(star)}
            className={`h-5 w-5 ${readOnly ? 'cursor-default' : 'cursor-pointer hover:scale-110 transition-transform'}`}
          >
            <Star
              className={`h-5 w-5 ${
                star <= rating
                  ? 'text-yellow-400 fill-yellow-400'
                  : 'text-gray-300'
              }`}
            />
          </button>
        ))}
      </div>
    )
  }

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-2 text-sm text-gray-600">Cargando clientes...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Clientes</h1>
          <p className="text-gray-600">Gestiona la información de tus clientes</p>
        </div>
        <Button 
          onClick={() => {
            setEditingClient(null)
            setFormData(initialFormData)
            setShowForm(true)
          }}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Nuevo Cliente
        </Button>
      </div>

      {/* Formulario */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>
              {editingClient ? 'Editar Cliente' : 'Nuevo Cliente'}
            </CardTitle>
            <CardDescription>
              Completa la información del cliente
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Nombre Completo *</label>
                  <Input
                    value={formData.full_name}
                    onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                    placeholder="Juan Pérez"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Teléfono *</label>
                  <Input
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="8888-8888"
                    maxLength={9}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Correo Electrónico</label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="juan@ejemplo.com"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Departamento</label>
                  <select
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  >
                    <option value="">Seleccionar departamento</option>
                    {departments.map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Ciudad</label>
                  <Input
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="Managua"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Calificación</label>
                  <StarRating
                    rating={formData.rating}
                    onChange={(rating) => setFormData({ ...formData, rating })}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Dirección</label>
                <Input
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Casa #123, Barrio Los Ángeles"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Notas</label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Información adicional sobre el cliente..."
                  rows={3}
                />
              </div>
              
              <div className="flex gap-2">
                <Button type="submit">
                  {editingClient ? 'Actualizar' : 'Crear'} Cliente
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowForm(false)
                    setEditingClient(null)
                    setFormData(initialFormData)
                  }}
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Filtros */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Buscar por nombre, teléfono o email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <select
                value={ratingFilter || ''}
                onChange={(e) => setRatingFilter(e.target.value ? parseInt(e.target.value) : null)}
                className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm"
              >
                <option value="">Todas las calificaciones</option>
                <option value="5">5 estrellas</option>
                <option value="4">4 estrellas</option>
                <option value="3">3 estrellas</option>
                <option value="2">2 estrellas</option>
                <option value="1">1 estrella</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de clientes */}
      <div className="grid gap-4">
        {/* Input oculto para subir fotos */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="hidden"
        />
        
        {filteredClients.length === 0 ? (
          <Card>
            <CardContent className="py-12">
              <div className="text-center text-gray-500">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-20" />
                <p>No hay clientes registrados</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          filteredClients.map((client) => {
            const initials = getInitials(client.full_name)
            const avatarColor = getAvatarColor(client.full_name)
            const isUploadingPhoto = uploadingFor === client.id
            
            return (
              <Card key={client.id}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    {/* Avatar/Foto del cliente */}
                    <div className="relative group">
                      {client.photo_url ? (
                        <img
                          src={client.photo_url}
                          alt={client.full_name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                      ) : (
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold ${avatarColor}`}>
                          {initials}
                        </div>
                      )}
                      
                      {/* Botón para subir foto */}
                      <button
                        onClick={() => triggerPhotoUpload(client)}
                        disabled={isUploadingPhoto}
                        className="absolute -bottom-1 -right-1 p-1 bg-blue-600 text-white rounded-full hover:bg-blue-700 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-50"
                        title="Cambiar foto"
                      >
                        {isUploadingPhoto ? (
                          <div className="animate-spin rounded-full h-3 w-3 border border-white border-t-transparent"></div>
                        ) : (
                          <Camera className="h-3 w-3" />
                        )}
                      </button>
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">
                            {client.full_name}
                          </h3>
                          <StarRating rating={client.rating || 0} readOnly />
                        </div>
                        
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(client)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDelete(client)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-gray-400" />
                          <span>{formatPhone(client.phone)}</span>
                        </div>
                        
                        {client.email && (
                          <div className="flex items-center gap-2">
                            <Mail className="h-4 w-4 text-gray-400" />
                            <span className="truncate">{client.email}</span>
                          </div>
                        )}
                        
                        {(client.city || client.department) && (
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-gray-400" />
                            <span>{[client.city, client.department].filter(Boolean).join(', ')}</span>
                          </div>
                        )}
                      </div>
                      
                      {client.address && (
                        <p className="text-sm text-gray-600 mt-2">
                          <strong>Dirección:</strong> {client.address}
                        </p>
                      )}
                      
                      {client.notes && (
                        <p className="text-sm text-gray-600 mt-2">
                          <strong>Notas:</strong> {client.notes}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })
        )}
      </div>
    </div>
  )
}