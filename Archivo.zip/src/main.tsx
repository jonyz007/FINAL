import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'

// Configuración de desarrollo para debugging
if (import.meta.env.DEV) {
  // Configuraciones de desarrollo
  console.log('CRM Nicaragua - Modo Desarrollo')
  console.log('Version:', import.meta.env.VITE_APP_VERSION || '1.0.0')
}

// Crear y renderizar la aplicación
ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)