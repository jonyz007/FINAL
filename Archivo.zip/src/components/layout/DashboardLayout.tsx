import React, { useState } from 'react'
import { Outlet, Link, useLocation, Navigate } from 'react-router-dom'
import { useAuth } from '@/contexts/AuthContext'
import { Button } from '@/components/ui/Button'
import { 
  Building2, 
  LayoutDashboard, 
  Users, 
  UserPlus,
  ShoppingCart, 
  FileText, 
  Settings, 
  Menu, 
  X, 
  LogOut,
  User
} from 'lucide-react'
import { cn, getInitials, getAvatarColor } from '@/lib/utils'
import { toast } from 'sonner'

interface SidebarItemProps {
  to: string
  icon: React.ReactNode
  label: string
  isActive: boolean
  onClick?: () => void
}

function SidebarItem({ to, icon, label, isActive, onClick }: SidebarItemProps) {
  return (
    <Link
      to={to}
      onClick={onClick}
      className={cn(
        'flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
        isActive
          ? 'bg-blue-600 text-white'
          : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'
      )}
    >
      {icon}
      {label}
    </Link>
  )
}

export default function DashboardLayout() {
  const { user, profile, loading, signOut } = useAuth()
  const location = useLocation()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-sm text-gray-600">Cargando...</p>
        </div>
      </div>
    )
  }

  if (!user || !profile) {
    return <Navigate to="/login" replace />
  }

  const handleSignOut = async () => {
    try {
      await signOut()
    } catch (error) {
      toast.error('Error al cerrar sesión')
    }
  }

  const getMenuItems = () => {
    const baseItems = [
      {
        to: '/dashboard',
        icon: <LayoutDashboard className="h-5 w-5" />,
        label: 'Dashboard'
      },
      {
        to: '/clientes',
        icon: <Users className="h-5 w-5" />,
        label: 'Clientes'
      },
      {
        to: '/ventas',
        icon: <ShoppingCart className="h-5 w-5" />,
        label: 'Ventas'
      },
      {
        to: '/reportes',
        icon: <FileText className="h-5 w-5" />,
        label: 'Reportes'
      }
    ]

    // Solo admins pueden ver usuarios
    if (profile.role === 'admin') {
      baseItems.splice(2, 0, {
        to: '/usuarios',
        icon: <UserPlus className="h-5 w-5" />,
        label: 'Usuarios'
      })
    }

    return baseItems
  }

  const menuItems = getMenuItems()
  const userInitials = getInitials(profile.full_name)
  const avatarColor = getAvatarColor(profile.full_name)

  const Sidebar = ({ className }: { className?: string }) => (
    <div className={cn('bg-white border-r border-gray-200 flex flex-col', className)}>
      {/* Logo */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <Building2 className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-gray-900">CRM Nicaragua</h1>
            <p className="text-xs text-gray-500">Sistema de Clientes</p>
          </div>
        </div>
      </div>

      {/* Navegación */}
      <nav className="flex-1 p-4 space-y-2">
        {menuItems.map((item) => (
          <SidebarItem
            key={item.to}
            to={item.to}
            icon={item.icon}
            label={item.label}
            isActive={location.pathname === item.to}
            onClick={() => setSidebarOpen(false)}
          />
        ))}
      </nav>

      {/* Perfil del usuario */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center gap-3 mb-3">
          <div className={cn('w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-semibold', avatarColor)}>
            {userInitials}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-gray-900 truncate">
              {profile.full_name}
            </p>
            <p className="text-xs text-gray-500 capitalize">
              {profile.role}
            </p>
          </div>
        </div>
        
        <div className="space-y-1">
          <Link
            to="/perfil"
            className="flex items-center gap-2 w-full px-2 py-1 text-xs text-gray-600 hover:text-gray-900 rounded"
            onClick={() => setSidebarOpen(false)}
          >
            <User className="h-3 w-3" />
            Mi Perfil
          </Link>
          <button
            onClick={handleSignOut}
            className="flex items-center gap-2 w-full px-2 py-1 text-xs text-red-600 hover:text-red-700 rounded"
          >
            <LogOut className="h-3 w-3" />
            Cerrar Sesión
          </button>
        </div>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar para desktop */}
      <div className="hidden lg:flex lg:w-64 lg:fixed lg:inset-y-0">
        <Sidebar />
      </div>

      {/* Sidebar móvil */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="fixed inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <div className="relative w-64 bg-white">
            <Sidebar />
          </div>
        </div>
      )}

      {/* Contenido principal */}
      <div className="lg:ml-64 flex flex-col min-h-screen">
        {/* Header móvil */}
        <header className="lg:hidden bg-white border-b border-gray-200 px-4 py-3">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="h-6 w-6" />
            </Button>
            <div className="flex items-center gap-2">
              <Building2 className="h-6 w-6 text-blue-600" />
              <span className="font-semibold text-gray-900">CRM</span>
            </div>
            <div className={cn('w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-semibold', avatarColor)}>
              {userInitials}
            </div>
          </div>
        </header>

        {/* Contenido */}
        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}