import { useState } from 'react'
import { supabase } from '@/lib/supabase'
import { toast } from 'sonner'

interface UploadClientPhotoParams {
  file: File
  clientId: string
}

export function useClientPhotoUpload() {
  const [uploading, setUploading] = useState(false)

  const uploadPhoto = async ({ file, clientId }: UploadClientPhotoParams): Promise<string | null> => {
    if (!file || !clientId) {
      toast.error('Archivo y ID de cliente son requeridos')
      return null
    }

    // Validaciones del lado del cliente
    const maxSize = 3 * 1024 * 1024 // 3MB
    if (file.size > maxSize) {
      toast.error('La imagen debe ser menor a 3MB')
      return null
    }

    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp']
    if (!allowedTypes.includes(file.type)) {
      toast.error('Solo se permiten imágenes JPEG, PNG y WebP')
      return null
    }

    try {
      setUploading(true)

      // Convertir archivo a base64
      const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader()
        reader.onloadend = () => resolve(reader.result as string)
        reader.onerror = reject
        reader.readAsDataURL(file)
      })

      // Usar edge function para subir la imagen
      const { data, error } = await supabase.functions.invoke('upload-client-photo', {
        body: {
          imageData: base64Data,
          fileName: file.name,
          clientId
        }
      })

      if (error) {
        console.error('Error subiendo foto:', error)
        toast.error(error.message || 'Error al subir la foto')
        return null
      }

      if (data?.error) {
        console.error('Error en edge function:', data.error)
        toast.error(data.error.message || 'Error al procesar la foto')
        return null
      }

      const publicUrl = data?.data?.publicUrl
      if (!publicUrl) {
        toast.error('No se pudo obtener la URL de la imagen')
        return null
      }

      toast.success('Foto subida exitosamente')
      return publicUrl

    } catch (error) {
      console.error('Error en uploadPhoto:', error)
      toast.error('Error inesperado al subir la foto')
      return null
    } finally {
      setUploading(false)
    }
  }

  // Función de fallback si la edge function no está disponible
  const uploadPhotoFallback = async ({ file, clientId }: UploadClientPhotoParams): Promise<string | null> => {
    try {
      setUploading(true)

      // Generar nombre único
      const timestamp = Date.now()
      const extension = file.name.split('.').pop()
      const fileName = `client_${clientId}_${timestamp}.${extension}`

      // Subir directamente a Supabase Storage
      const { data, error } = await supabase.storage
        .from('client-photos')
        .upload(fileName, file, {
          upsert: true
        })

      if (error) {
        throw error
      }

      // Obtener URL pública
      const { data: urlData } = supabase.storage
        .from('client-photos')
        .getPublicUrl(fileName)

      const publicUrl = urlData.publicUrl

      // Actualizar cliente con la nueva foto
      const { error: updateError } = await supabase
        .from('clients')
        .update({ photo_url: publicUrl })
        .eq('id', clientId)

      if (updateError) {
        // Si falló la actualización, eliminar la imagen
        await supabase.storage.from('client-photos').remove([fileName])
        throw updateError
      }

      toast.success('Foto subida exitosamente')
      return publicUrl

    } catch (error) {
      console.error('Error en uploadPhotoFallback:', error)
      toast.error('Error al subir la foto')
      return null
    } finally {
      setUploading(false)
    }
  }

  return {
    uploadPhoto,
    uploadPhotoFallback,
    uploading
  }
}