Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        // Get environment variables
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');

        if (!serviceRoleKey || !supabaseUrl) {
            throw new Error('Supabase configuration missing');
        }

        // Crear tablas si no existen
        const createTablesSQL = `
        -- Crear tabla de perfiles
        CREATE TABLE IF NOT EXISTS profiles (
            id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
            email VARCHAR(255) NOT NULL,
            full_name VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL CHECK (role IN ('admin', 'vendedor', 'impresor')),
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        -- Crear tabla de clientes
        CREATE TABLE IF NOT EXISTS clients (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            full_name VARCHAR(255) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            email VARCHAR(255),
            address TEXT,
            city VARCHAR(100),
            department VARCHAR(100),
            rating INTEGER CHECK (rating >= 1 AND rating <= 5),
            notes TEXT,
            photo_url VARCHAR(500),
            created_by UUID NOT NULL,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        -- Crear tabla de ventas
        CREATE TABLE IF NOT EXISTS sales (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            client_id UUID NOT NULL,
            seller_id UUID NOT NULL,
            product_name VARCHAR(255) NOT NULL,
            quantity INTEGER NOT NULL,
            unit_price DECIMAL(10,2) NOT NULL,
            total_amount DECIMAL(10,2) NOT NULL,
            currency VARCHAR(10) DEFAULT 'NIO',
            status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'cancelled')),
            sale_date DATE NOT NULL,
            notes TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        -- Habilitar RLS
        ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
        ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
        ALTER TABLE sales ENABLE ROW LEVEL SECURITY;

        -- Políticas de seguridad para profiles
        DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
        CREATE POLICY "Users can view own profile" ON profiles
            FOR SELECT USING (auth.uid() = id);

        DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
        CREATE POLICY "Users can update own profile" ON profiles
            FOR UPDATE USING (auth.uid() = id);

        DROP POLICY IF EXISTS "Admins can manage all profiles" ON profiles;
        CREATE POLICY "Admins can manage all profiles" ON profiles
            FOR ALL USING (
                EXISTS (
                    SELECT 1 FROM profiles 
                    WHERE id = auth.uid() AND role = 'admin'
                )
            );

        -- Políticas de seguridad para clients
        DROP POLICY IF EXISTS "Users can view relevant clients" ON clients;
        CREATE POLICY "Users can view relevant clients" ON clients
            FOR SELECT USING (
                created_by = auth.uid() OR
                EXISTS (
                    SELECT 1 FROM profiles 
                    WHERE id = auth.uid() AND role IN ('admin', 'impresor')
                )
            );

        DROP POLICY IF EXISTS "Sellers can insert clients" ON clients;
        CREATE POLICY "Sellers can insert clients" ON clients
            FOR INSERT WITH CHECK (
                created_by = auth.uid() AND
                EXISTS (
                    SELECT 1 FROM profiles 
                    WHERE id = auth.uid() AND role IN ('admin', 'vendedor')
                )
            );

        DROP POLICY IF EXISTS "Users can update relevant clients" ON clients;
        CREATE POLICY "Users can update relevant clients" ON clients
            FOR UPDATE USING (
                created_by = auth.uid() OR
                EXISTS (
                    SELECT 1 FROM profiles 
                    WHERE id = auth.uid() AND role = 'admin'
                )
            );

        DROP POLICY IF EXISTS "Users can delete relevant clients" ON clients;
        CREATE POLICY "Users can delete relevant clients" ON clients
            FOR DELETE USING (
                created_by = auth.uid() OR
                EXISTS (
                    SELECT 1 FROM profiles 
                    WHERE id = auth.uid() AND role = 'admin'
                )
            );

        -- Políticas de seguridad para sales
        DROP POLICY IF EXISTS "Users can view relevant sales" ON sales;
        CREATE POLICY "Users can view relevant sales" ON sales
            FOR SELECT USING (
                seller_id = auth.uid() OR
                EXISTS (
                    SELECT 1 FROM profiles 
                    WHERE id = auth.uid() AND role IN ('admin', 'impresor')
                )
            );

        DROP POLICY IF EXISTS "Sellers can insert sales" ON sales;
        CREATE POLICY "Sellers can insert sales" ON sales
            FOR INSERT WITH CHECK (
                seller_id = auth.uid() AND
                EXISTS (
                    SELECT 1 FROM profiles 
                    WHERE id = auth.uid() AND role IN ('admin', 'vendedor')
                )
            );

        DROP POLICY IF EXISTS "Users can update relevant sales" ON sales;
        CREATE POLICY "Users can update relevant sales" ON sales
            FOR UPDATE USING (
                seller_id = auth.uid() OR
                EXISTS (
                    SELECT 1 FROM profiles 
                    WHERE id = auth.uid() AND role = 'admin'
                )
            );

        DROP POLICY IF EXISTS "Users can delete relevant sales" ON sales;
        CREATE POLICY "Users can delete relevant sales" ON sales
            FOR DELETE USING (
                seller_id = auth.uid() OR
                EXISTS (
                    SELECT 1 FROM profiles 
                    WHERE id = auth.uid() AND role = 'admin'
                )
            );

        -- Función para actualizar updated_at automáticamente
        CREATE OR REPLACE FUNCTION update_updated_at_column()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$ language 'plpgsql';

        -- Triggers para actualizar updated_at
        DROP TRIGGER IF EXISTS update_profiles_updated_at ON profiles;
        CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

        DROP TRIGGER IF EXISTS update_clients_updated_at ON clients;
        CREATE TRIGGER update_clients_updated_at BEFORE UPDATE ON clients
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

        DROP TRIGGER IF EXISTS update_sales_updated_at ON sales;
        CREATE TRIGGER update_sales_updated_at BEFORE UPDATE ON sales
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
        `;

        // Ejecutar SQL usando la API REST de Supabase
        const sqlResponse = await fetch(`${supabaseUrl}/rest/v1/rpc/exec_sql`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ sql: createTablesSQL })
        });

        if (!sqlResponse.ok) {
            // Si no existe la función exec_sql, usar approach directo
            console.log('Direct SQL execution not available, tables may need manual creation');
        }

        // Crear usuario administrador
        const adminEmail = 'admin@crm.com';
        const adminPassword = 'admin';

        // Verificar si el usuario admin ya existe
        const existingUserResponse = await fetch(`${supabaseUrl}/auth/v1/admin/users`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });

        let adminExists = false;
        let adminUserId = null;

        if (existingUserResponse.ok) {
            const users = await existingUserResponse.json();
            const adminUser = users.users?.find((user: any) => user.email === adminEmail);
            if (adminUser) {
                adminExists = true;
                adminUserId = adminUser.id;
            }
        }

        // Crear usuario si no existe
        if (!adminExists) {
            const createUserResponse = await fetch(`${supabaseUrl}/auth/v1/admin/users`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    email: adminEmail,
                    password: adminPassword,
                    email_confirm: true
                })
            });

            if (createUserResponse.ok) {
                const newUser = await createUserResponse.json();
                adminUserId = newUser.id;
            } else {
                const errorText = await createUserResponse.text();
                console.log('Failed to create admin user:', errorText);
            }
        }

        // Crear perfil de administrador si tenemos el ID del usuario
        if (adminUserId) {
            const profileResponse = await fetch(`${supabaseUrl}/rest/v1/profiles`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json',
                    'Prefer': 'resolution=merge-duplicates'
                },
                body: JSON.stringify({
                    id: adminUserId,
                    email: adminEmail,
                    full_name: 'Administrador',
                    role: 'admin'
                })
            });

            if (!profileResponse.ok) {
                const errorText = await profileResponse.text();
                console.log('Failed to create admin profile:', errorText);
            }
        }

        // Crear bucket para fotos de clientes
        const bucketResponse = await fetch(`${supabaseUrl}/storage/v1/bucket`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id: 'client-photos',
                name: 'client-photos',
                public: true
            })
        });

        // 409 significa que ya existe, lo cual está bien
        const bucketCreated = bucketResponse.ok || bucketResponse.status === 409;

        return new Response(JSON.stringify({
            data: {
                message: 'Database initialization completed',
                tablesCreated: true,
                adminUserExists: adminExists,
                adminUserCreated: !adminExists && adminUserId !== null,
                bucketCreated: bucketCreated,
                adminCredentials: {
                    email: adminEmail,
                    password: adminPassword
                }
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Database initialization error:', error);

        const errorResponse = {
            error: {
                code: 'DATABASE_INIT_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});