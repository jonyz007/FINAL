Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { imageData, fileName, clientId } = await req.json();

        if (!imageData || !fileName || !clientId) {
            throw new Error('Image data, filename and client ID are required');
        }

        // Get the service role key
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');

        if (!serviceRoleKey || !supabaseUrl) {
            throw new Error('Supabase configuration missing');
        }

        // Verificar autenticación
        const authHeader = req.headers.get('authorization');
        if (!authHeader) {
            throw new Error('No authorization header');
        }

        const token = authHeader.replace('Bearer ', '');

        // Verificar token y obtener usuario
        const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'apikey': serviceRoleKey
            }
        });

        if (!userResponse.ok) {
            throw new Error('Invalid token');
        }

        const userData = await userResponse.json();
        const userId = userData.id;

        // Verificar que el usuario tiene permisos para subir fotos para este cliente
        const clientResponse = await fetch(`${supabaseUrl}/rest/v1/clients?id=eq.${clientId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            }
        });

        if (!clientResponse.ok) {
            throw new Error('Error checking client permissions');
        }

        const clientData = await clientResponse.json();
        if (!clientData || clientData.length === 0) {
            throw new Error('Client not found');
        }

        const client = clientData[0];
        
        // Verificar permisos: solo el creador del cliente o un admin puede subir fotos
        const profileResponse = await fetch(`${supabaseUrl}/rest/v1/profiles?id=eq.${userId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });

        if (!profileResponse.ok) {
            throw new Error('Error checking user profile');
        }

        const profileData = await profileResponse.json();
        if (!profileData || profileData.length === 0) {
            throw new Error('User profile not found');
        }

        const userProfile = profileData[0];
        
        if (client.created_by !== userId && userProfile.role !== 'admin') {
            throw new Error('You do not have permission to upload photos for this client');
        }

        // Validar imagen
        if (!imageData.startsWith('data:image/')) {
            throw new Error('Invalid image format');
        }

        // Extract base64 data from data URL
        const base64Data = imageData.split(',')[1];
        const mimeType = imageData.split(';')[0].split(':')[1];

        // Validar tamaño (máximo 3MB)
        const binaryData = Uint8Array.from(atob(base64Data), c => c.charCodeAt(0));
        const maxSize = 3 * 1024 * 1024; // 3MB en bytes
        
        if (binaryData.length > maxSize) {
            throw new Error('Image size must be less than 3MB');
        }

        // Validar tipo de imagen
        const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
        if (!allowedTypes.includes(mimeType)) {
            throw new Error('Only JPEG, PNG and WebP images are allowed');
        }

        // Generar nombre único para el archivo
        const timestamp = Date.now();
        const extension = mimeType.split('/')[1];
        const uniqueFileName = `client_${clientId}_${timestamp}.${extension}`;

        // Crear bucket si no existe
        const bucketResponse = await fetch(`${supabaseUrl}/storage/v1/bucket/client-photos`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id: 'client-photos',
                name: 'client-photos',
                public: true
            })
        });

        // Si el bucket ya existe, el error 409 es esperado
        if (!bucketResponse.ok && bucketResponse.status !== 409) {
            console.log('Bucket creation failed, but continuing...');
        }

        // Upload to Supabase Storage
        const uploadResponse = await fetch(`${supabaseUrl}/storage/v1/object/client-photos/${uniqueFileName}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'Content-Type': mimeType,
                'x-upsert': 'true'
            },
            body: binaryData
        });

        if (!uploadResponse.ok) {
            const errorText = await uploadResponse.text();
            throw new Error(`Upload failed: ${errorText}`);
        }

        // Get public URL
        const publicUrl = `${supabaseUrl}/storage/v1/object/public/client-photos/${uniqueFileName}`;

        // Actualizar el cliente con la nueva URL de foto
        const updateResponse = await fetch(`${supabaseUrl}/rest/v1/clients?id=eq.${clientId}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                photo_url: publicUrl
            })
        });

        if (!updateResponse.ok) {
            const errorText = await updateResponse.text();
            // Si falló la actualización, intentar eliminar la imagen subida
            try {
                await fetch(`${supabaseUrl}/storage/v1/object/client-photos/${uniqueFileName}`, {
                    method: 'DELETE',
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`
                    }
                });
            } catch (deleteError) {
                console.error('Failed to cleanup uploaded image:', deleteError);
            }
            throw new Error(`Failed to update client: ${errorText}`);
        }

        return new Response(JSON.stringify({
            data: {
                publicUrl,
                fileName: uniqueFileName,
                clientId,
                message: 'Photo uploaded successfully'
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Photo upload error:', error);

        const errorResponse = {
            error: {
                code: 'PHOTO_UPLOAD_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});